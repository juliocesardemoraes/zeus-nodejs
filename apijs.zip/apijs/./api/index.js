import app from "../src/index.js";

export default app;
